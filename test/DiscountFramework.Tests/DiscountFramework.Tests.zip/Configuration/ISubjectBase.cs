namespace DiscountFramework.Tests.Configuration
{
    public interface ISubjectBase
    {
        void FixtureSetup();
        void FixtureTearDown();
    }
}